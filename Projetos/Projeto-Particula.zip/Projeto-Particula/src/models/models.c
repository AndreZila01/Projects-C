#include "models.h"

#include <stdlib.h>

#define _XOPEN_SOURCE 500
#include <string.h>

User new_user(char* name) {
    User user = malloc(sizeof(User_));
    user->name = name;
    return user;
}

void free_user(User user) {
    free(user->name);
    free(user);
    // TODO: Falta atualizar para os novos campos de User.
}

void free_user(App app)
{
    hash_table_destroy(app->users);
    free(app);
}

void* ValueOfUser(App app, char *name)
{
    return hash_table_get(app->users, name);
}

bool has_user(App app, char *name)
{
    return hash_table_get(app->users, name) != NULL;
}

void register_user(App app, char *name)
{
    User user = new_app(name);
    hash_table_insert(app->users, name, user);
}

int SizeOfHash(App usern)
{
    return hash_table_size(usern->users);
}

void list_user(App usern)
{
    void *value = hash_table_values(usern);
    int lenght = hash_table_size(usern), val=0;

    // não consigo ter o node desta solução??
    while (lenght != val)
    {
        printf("Espaço de simulação registado com identificador %s.\n", hash_table_get(usern, val));
        val++;
    }
}

#pragma endregion

#pragma region simulation_spaces

User new_simulation(char *username)
{
    User app = malloc(sizeof(tApp));
    app->name = NULL;
    app->simulation_spaces = hash_table_create(0, NULL, NULL, NULL, (void (*)(void *))free_user);
    return app;
}

void free_simulation(User usern)
{
    hash_table_destroy(usern->simulation_spaces);
    free(usern);
}

bool has_simulation(User usern, char *name)
{
    return hash_table_get(usern->simulation_spaces, name) != NULL;
}

void register_simulation(User usern, char *name)
{
    User user = hash_table_get(usern, name);
    // 0. Criar o identificador de espaço
    char* space_id;
    sprintf(space_id, "%d", user->simulation_spaces);
    user->name = name;
    // 1. Criar um novo espaço
    SpaceSimulation space = new_space(space_id);
    // 2. Colocar o espaço na tabela de dispersão de espaços de simulação, do utilizador
    hash_table_insert(user->simulation_spaces, space->id, space);
    return space->id;
    //User user = new_app(name);
    //hash_table_insert(usern->simulation_spaces, name, user);
}


#pragma endregion

#pragma region particle

SpaceSimulation new_space()
{
    App app = malloc(sizeof(Particle_));
    app->users = hash_table_create(0, NULL, NULL, NULL, (void (*)(void *))free_user);
    return app;
}

void free_space(SpaceSimulation app)
{
    hash_table_destroy(app->particle);
    free(app);
}

bool has_space(SpaceSimulation app, char *name)
{
    return hash_table_get(app->particle, name) != NULL;
}

void register_space(SpaceSimulation app, char *name)
{
    User user = new_app(name);
    hash_table_insert(app->particle, name, user);
}