#include "views/cli.h"

int main() {
    run_cli();
    return 0;
}